package com.example.calculator;

public class Operaciones {

    public Operaciones(){

    }

    public float suma(float a, float b, boolean sum){
        if(sum){
            return b;
        }else{
            return a + suma(a,b, true);
        }
    }

    public float resta(float a, float b, boolean res){
        if(res){
            return b;
        }else{
            return a - resta(a,b,true);
        }
    }

    public float div(float a, float b, boolean divi){
        if(divi){
            return b;
        }else{
            return a - resta(a,b,true);
        }
    }

    public float mult(float a, float b, boolean multi){
        if(multi){
            return b;
        }else{
            return a - resta(a,b,true);
        }
    }

    public float exp(float a, float b){
        if(b == 0){
            return 1;
        }else{
            return a*(exp(a,b-1));
        }
    }

    private double multiply(double mid, float a){
        double ans = 1.0;
        for(int i = 1;i<=a;i++) {
            ans = ans * mid;
        }
        return ans;
    }

    public double root(int a, int b){
        double low = 1;
        double high = b;
        double eps = 1e-6;

        while((high - low) > eps) {
            double mid = (low + high) / 2.0;
            if(multiply(mid, a) < b) {
                low = mid;
            }
            else {
                high = mid;
            }
        }
        return low;
    }

    public float fact(float a){
        if(a == 0){
            return 1;
        }else{
            return a * fact(a-1);
        }
    }

    public float log(float a, float b){
        return -1;
    }

    public int tan(float a){
        return -1;
    }

    public int cos(float a){
        return -1;
    }

    public int sen(float a){
        return -1;
    }
}
