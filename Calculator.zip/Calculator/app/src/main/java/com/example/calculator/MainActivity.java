package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.concurrent.TimeUnit;
import org.apache.commons.lang3.time.StopWatch;

public class MainActivity extends AppCompatActivity {

    private TextView display, result;
    private EditText a, b;
    private Operaciones calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        result = findViewById(R.id.result);
        a = findViewById(R.id.a);
        b = findViewById(R.id.b);
        calc = new Operaciones();
    }

    public void clear(View view) {
        display.setText("");
        result.setText("");
        a.setText("");
        b.setText("");
    }

    public void root(View view) {
        display.setText("√");
    }

    public void exp(View view) {
        display.setText("^");
    }

    public void divide(View view) {
        display.setText("÷");
    }

    public void mult(View view) {
        display.setText("×");
    }

    public void restar(View view) {
        display.setText("-");
    }

    public void add(View view) {
        display.setText("+");
    }

    public void fact(View view) {
        display.setText("!");
    }

    public void log(View view) {
        display.setText(String.valueOf("log"));
    }

    public void tangente(View view) {
        display.setText(String.valueOf("tan"));
    }

    public void coseno(View view) {
        display.setText(String.valueOf("cos"));
    }

    public void seno(View view) {
        display.setText(String.valueOf("sin"));
    }

    public void equal(View view) {
        String op = display.getText().toString();
        String vA = a.getText().toString();
        String vB = b.getText().toString();
        StopWatch crono = new StopWatch();

        switch (op) {
            case "+":
                crono.start();
                result.setText(String.valueOf(calc.suma(Float.parseFloat(vA), Float.parseFloat(vB), false)));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                break;
            case "-":
                crono.start();
                result.setText(String.valueOf(calc.resta(Float.parseFloat(vA), Float.parseFloat(vB), false)));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                break;
            case "÷":

                if(Float.parseFloat(vB) == 0){
                    result.setText("Math Error");
                }
                else{
                    crono.start();
                    result.setText(String.valueOf(calc.div(Float.parseFloat(vA), Float.parseFloat(vB), false)));
                    crono.stop();
                    Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                }
                break;
            case "×":
                crono.start();
                result.setText(String.valueOf(calc.mult(Float.parseFloat(vA), Float.parseFloat(vB), false)));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                break;
            case "^":
                crono.start();
                result.setText(String.valueOf(calc.exp(Float.parseFloat(vA), Float.parseFloat(vB))));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                break;
            case "√":
                if(Float.parseFloat(vB) < 0 || Float.parseFloat(vA) < 0){
                    result.setText("Math Error");
                }else{
                    crono.start();
                    result.setText(String.valueOf(Math.round(calc.root(Integer.parseInt(vA), Integer.parseInt(vB)))));
                    crono.stop();
                    Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                }
                break;
            case "!":
                crono.start();
                result.setText(String.valueOf(calc.fact(Float.parseFloat(vA))));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();
                break;
            case "log":
                result.setText("Proximamente");
                /*crono.start();
                result.setText(String.valueOf(calc.log(Float.parseFloat(vA), Float.parseFloat(vB))));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();*/
                break;
            case "tan":
                result.setText("Proximamente");
                /*crono.start();
                result.setText(String.valueOf(calc.tan(Float.parseFloat(vA))));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();*/
                break;
            case "cos":
                result.setText("Proximamente");
                /*crono.start();
                result.setText(String.valueOf(calc.cos(Float.parseFloat(vA))));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();*/
                break;
            case "sin":
                result.setText("Proximamente");
                /*crono.start();
                result.setText(String.valueOf(calc.sen(Float.parseFloat(vA))));
                crono.stop();
                Toast.makeText(this, String.valueOf(crono.getNanoTime()/1000000f) + " ms", Toast.LENGTH_SHORT).show();*/
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + op);
        }
    }
}